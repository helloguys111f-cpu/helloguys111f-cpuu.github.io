



print("Quad Terminal version 2.0")
un = input("Username:")
pw = input("Password:")
i = 0
    with open("quaduser") as f:
        for line in f:
            i = i + 1
            if i == 1:
                if un == line:
                    continue
                else:
                    print("Incorrect !")
            if i == 2:
                if pw == line:
                    break
                else:
                    print("Incorrect !")
            
import sys

import os


def pb(iteration):
    sum1 = "|" # border
    sum2 = "█" # put here sumbol
    sum3 = "." # empty
    screen = "Starting Quad: " + sum1 + sum2 * iteration + sum3 * (13 - len((sum2 * iteration))) + sum1 + " " + str(((len(sum3*iteration) * 2))) + "% Complemented"
    sys.stdout.write('\r'+screen)

pb(1)
import pip
pb(2)
import time
pb(3)
time.sleep(0.1)
import wget
pb(4)
time.sleep(0.1)
import traceback
pb(5)
time.sleep(0.1)
import socket
pb(6)
time.sleep(0.1)
import tarfile
pb(7)
time.sleep(0.1)
import requests
pb(8)
time.sleep(0.1)
import netifaces as net
pb(9)
time.sleep(0.1)
import fnmatch
pb(10)
time.sleep(0.1)
import glob
pb(11)
time.sleep(0.1)
import shutil
pb(12)
time.sleep(0.1)
import platform
pb(13)
time.sleep(0.1)
print("\n")
syspath = os.getcwd().split('\Quad')[0]+'\Quad\home'
os.chdir(syspath.replace(r'\ ','/'))
if platform.system=='Windows':
    os.system('help')
    os.system('cls')
def find(pattern, path):
    result = []
    for root, dirs, files in os.walk(path):
        for name in files:
            if fnmatch.fnmatch(name, pattern):
                result.append(os.path.join(root, name))
    return str(result)
class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

print(colors.BOLD+"Welcome to Quad! \n  \n \n \n -Quad 1.1- \n Welcome back,you are "+os.getlogin() + " in linux! \n Type help to see commands for linux, \n type help to see \n Quad commands")


while 1:
	com = input(colors.BOLD + colors.OKBLUE+os.getcwd()+colors.OKGREEN+"~$" + colors.ENDC)
	if com.find('evalpy') == -1:
		pass
	else:
		arg = com.split('evalpy ')[-1]
		eval("str("+arg+")")
		continue
	if com.find('git') == -1:
		pass
	else:
		print('-Downloading file-')
		str = com.split('git ')[-1]
		wget.download(str,str.split('/')[-1])
		print('-File Downloaded,unpacking...-')
		
	if com.find("getip") == -1:
		pass
	else:
		hostname = socket.gethostname()
		local_ip = socket.gethostbyname(hostname)
		print(colors.HEADER+"Your local IP adress is:"+local_ip)
		public_ip = requests.get('https://api.ipify.org').text
		print(colors.HEADER+"Your public IP adress is:"+public_ip)
		print(colors.HEADER+str(list(net.interfaces())))


		
		continue
	if com.find("help") == -1:
		pass
	else:
		print("Quad commands: \n ----------------- \n whoiam - Print your current login. \n\n     get <url> - Download file \n\n     qp - (experemental) install Quad package. It should be in zip file, where is a package build, and install.sh file,that installs package \n\n getip - shows some data like local ip and public ip \n \n    evalpy - execute python code")
		os.system('help')
		continue
	if com.find("whoiam") == -1:
		pass
	else:
		print(colors.OKCYAN+"Congurations ! You are "+os.getlogin() + " in linux!")
		continue
	if com.find("cd") == -1:
		pass
	else:
	   	try:
	   		str=com.split('cd ')[1]
	   		os.chdir(str)
	   	except Exception as e:
	   		print(colors.FAIL+"ErrorSafe:"+traceback.format_exc())
	   	continue
	if com.find("get") == -1:
		pass
	else:
		str = com.split('get ')[1]
		try:
		    wget.download(str,str.split('/')[-1])
		except Exception as e:
			print(colors.FAIL+"ErrorSafe saved your session from error:"+traceback.format_exc())
		continue
	if com.find("qp") == -1:
		pass
	else:
		try:
			print(colors.OKBLUE+"Preparing to install...")
			ask = input("Do you want to install package from our repo? Y[es] N[o]")
			if ask == "N":
				str = input("Enter package url:")
			elif ask == "Y":
				str = input("Enter package name:")
				str = "https://quad-repo.github.io/"+str+".zip"
			modName = str.split('/')[-1]
			wget.download(str,modName)
			
			print('Fetching archive...')
			print(colors.WARNING+'Need to unzip ' + modName)
			fname=modName
			if fname.endswith('.zip'):
				shutil.unpack_archive(modName, os.getcwd())
			if fname.endswith("tar.gz"):
				tar = tarfile.open(fname, "r:gz")
				tar.extractall()
				tar.close()
			if fname.endswith("tar"):
			 	tar = tarfile.open(fname, "r:")
			 	tar.extractall()
			 	tar.close()
			print(colors.OKGREEN+"Unpacking complemented.Removing install archive...")
			os.system('rm '+modName)
			print(colors.OKGREEN+"Archive deleted.")
			print("--------Installation--------")
			modFolder = modName.replace('.zip','')
			print(colors.OKGREEN+'Installation prepared.')
			print(colors.OKGREEN+'Installing...')
			path = os.getcwd()
			dirs = os.listdir()
			for dir in dirs:
				os.system('bash ' + os.path.realpath(dir+'/install.sh'))
				if dir=="install.sh":
					os.system('bash install.sh')
					os.system('rm install.sh')
					break
				os.system('rm ' + os.path.realpath(dir+'/install.sh'))
			print(colors.HEADER+'--Package ' + modFolder + ' was successfully installed!-- \n')
			
		except Exception as e:
			print(colors.FAIL+"ErSafe:"+traceback.format_exc())
		continue
	os.system(com)
